QuickTrade Installer v1.0

How to Install:
1. Double-click QuickTradeInstaller_v1.0.exe to start installation.
2. Follow the setup wizard.
3. After installation, launch QuickTrade from your desktop.

Notes:
- This app is an unofficial SIGNUM companion.
- All API keys are stored locally.
- Data is private and stays on your device.

If you're a developer, see QuickTrade_Source/ for Python files.
