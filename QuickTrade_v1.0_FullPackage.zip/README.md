# QuickTrade

QuickTrade is a GUI-based crypto trading assistant.
