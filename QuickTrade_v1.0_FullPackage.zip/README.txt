Welcome to QuickTrade. Run 'main.py' to launch the app.
